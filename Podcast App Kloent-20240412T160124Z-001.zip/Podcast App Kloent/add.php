<?php
require_once("db.php");
include "header.php";

if(!empty($_POST["add_record"])) {
	$sql = "INSERT INTO tbl_episode (episodetitle, episodecode, episodepublishdate, episodeintro) VALUES ( :episode_title, :epcode, :post_at, :description )";
	$pdo_statement = $pdo_conn->prepare( $sql );
	$result = $pdo_statement->execute( array(':episode_title'=>$_POST['post_title'],':epcode'=>$_POST['episode_code'], ':post_at'=>$_POST['post_at'], ':description'=>$_POST['description'] ) );
	if (!empty($result) ){
	  header('location:index.php');
	}
}
?>

 <div class="container">
	<div style="margin:20px 10px"><a href="index.php" class="button_link">Back to List</a></div>
<div class="row frm-add">
<h1 class="demo-form-heading">Add New Record</h1>
<form name="frmAdd" action="" method="POST" class="form-group">
<div class="col-xs-12 col-sm-6 col-md-6">
  <div class="demo-form-row">
	  <label>Title: </label><br>
	  <input type="text" name="post_title" class="demo-form-field form-control" required/>
  </div>
	<div class="demo-form-row">
	  <label>Episode Code: </label><br>
	  <input type="text" name="episode_code" class="demo-form-field form-control" required/>
  </div>
	<div class="demo-form-row">
	  <label>Date: </label><br>
	  <input type="date" name="post_at" class="demo-form-field form-control"/>
  </div>
</div>
  <div class="col-xs-12 col-sm-6 col-md-6">
	  <div class="demo-form-row">
		  <label>Episode Intro: </label><br>
		  <textarea name="description" class="demo-form-field form-control" rows="5"></textarea>
	  </div>
		<div class="demo-form-row">
		<input name="add_record" type="submit" value="Add" class="demo-form-submit">
		</div>
	</div>
</form>
</div>
</div><!-- End container -->
<?php include "footer.php";?>
