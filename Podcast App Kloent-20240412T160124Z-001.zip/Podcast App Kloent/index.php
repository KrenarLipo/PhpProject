<?php
require_once("db.php");
include "header.php";
?>

<?php
   $limit = 20;
   $query = "SELECT * FROM tbl_episode";
   $s = $pdo_conn->prepare($query);
   $s->execute();
   $total_results = $s->rowCount();
   $total_pages = ceil($total_results/$limit);
   if(!isset($_GET['page'])){
      $page = 1;
   }else{
      $page = $_GET['page'];
   }
   $starting_limit = ($page-1)*$limit;
   $show = "SELECT `episodeid`,`episodetitle`,`episodecode`,`epstid`,`episodeintro`, `episodestatus`, `episodepublishdate` FROM `tbl_episode` as t INNER JOIN `tbl_episodestatus` as s ON t.epstid = s.episodestatusid ORDER BY episodeid ASC LIMIT $starting_limit, $limit";
   $r = $pdo_conn->prepare($show);
   $r->execute();
//$statusquery = "SELECT `status` FROM `tbl_epstatus` AS t INNER JOIN `tbl_episode` AS s ON t.id = s.epstid";
//$st = $pdo_conn->prepare($statusquery);
//$st->execute;
?>
<div class="container">
<div style="text-align:right;margin:20px 0px;"><a href="add.php" class="button_link"><img src="crud-icon/add.png" title="Add New Record" style="vertical-align:bottom;" /> Create</a></div>
<div class="row">
<table class="tbl-qa table-bordered table-responsive">
  <thead>
	<tr>
	  <th class="table-header" width="20%">Title</th>
    <th class="table-header" width="10%">Episode Code</th>
	  <th class="table-header" width="20%">Episode Intro</th>
	  <th class="table-header" width="30%">Status</th>
	  <th class="table-header" width="10%">Date</th>
	  <th class="table-header" width="10%">Actions</th>
	</tr>
  </thead>
  <tbody id="table-body">
	<?php
            while($res = $r->fetch(PDO::FETCH_ASSOC)):
	?>
	  <tr class="table-row">
      <?php $nums = [1,2,3,4,5,6]; ?>
		<td><?php echo $res["episodetitle"]; ?></td>
    <td><?php echo $res["episodecode"]; ?></td>
		<td><?php echo $res["episodeintro"]; ?></td>
		<td><span style="color:#428a8e;"><?php echo $res["episodestatus"];?></span> | <?php if (in_array($res['epstid'],$nums)){echo " <span style='color:#F00'>Yes</span> further steps ahead!";}else{echo" <span style='color:#F9A602'>No</span> further steps";};?></td>
		<td width="100%"><?php echo $res["episodepublishdate"]; ?></td>
		<td><a class="ajax-action-links" href='edit.php?id=<?php echo $res['episodeid']; ?>'><img src="crud-icon/edit.png" title="Edit" /></a><a class="ajax-action-links" href='tasks.php?id=<?php echo $res['episodeid']; ?>'><img src="crud-icon/task.png" title="Tasks" /></a></td>
	  </tr>
    <?php endwhile; ?>
  </tbody>
</table>
<?php for($page=1;$page<=$total_pages; $page++):?>
<a href='<?php echo "?page=$page"; ?>' class="links"><?php  echo $page; ?>
 </a>
<?php endfor; ?>
<?php
   $tasklimit = 4;
   $basicquery = "SELECT * FROM tblTasks";
   $t = $pdo_conn->prepare($basicquery);
   $t->execute();
   $tot_results = $t->rowCount();
   $tot_pages = ceil($tot_results/$tasklimit);
   if(!isset($_GET['taskpage'])){
      $taskpage = 1;
   }else{
      $taskpage = $_GET['taskpage'];
   }
   $start_limit = ($taskpage-1)*$tasklimit;

   $taskquery = "SELECT e.episodetitle, t.taskDescription, t.taskDate FROM tblTasks AS t INNER JOIN tbl_episode AS e WHERE t.taskEpisodeID = e.episodeid ORDER BY t.taskEpisodeID ASC LIMIT $start_limit, $tasklimit";
   $tq = $pdo_conn->prepare($taskquery);
   $tq->execute();
?>
      <div class="clearfix"></div>
      <h3 class="text-center">Task List</h3>
       <table class="tbl-qa table-bordered table-responsive">
           <thead>
              <tr class="table-row">
                <th class="table-header" width="40%">Episode Title</th>
                <th class="table-header" width="40%">Task Description</th>
                <th class="table-header" width="30%">Task Date</th>
              </tr>
           </thead>
       <?php
                 while($res = $tq->fetch(PDO::FETCH_ASSOC)):
     	?>
       <tbody id="table-body">
         <tr class="table-row">
          <td><?php echo $res['episodetitle'];?></td>
          <td><?php echo $res['taskDescription'];?></td>
          <td><?php echo $res['taskDate'];?></td>
        </tr>
         <?php endwhile;?>
       </tbody>
     </table>
     <?php for($taskpage=1;$taskpage<=$tot_pages; $taskpage++):?>
     <a href='<?php echo "?taskpage=$taskpage"; ?>' class="tasklinks"><?php  echo $taskpage; ?>
      </a>
     <?php endfor; ?>
   </div><!-- row -->
</div><!-- Container -->
<?php include "footer.php"; ?>
