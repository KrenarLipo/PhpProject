<?php
require_once("db.php");
include "header.php";
$names = array();
$guest_elements = array();
if(isset($_POST["save_record"])) {
  $guest_elements = implode(", ",$_POST['guestlist']);
	$pdo_statement=$pdo_conn->prepare("update tbl_episode set episodetitle='" . $_POST[ 'post_title' ] . "',episodeGuests='".$guest_elements."', episodeintro='" . $_POST[ 'description' ]. "', epstid = '".$_POST['statusupdate']."', episodepublishdate='" . $_POST[ 'post_at' ]. "' where episodeid=" . $_GET["id"]);
	$result = $pdo_statement->execute();
	if(!empty($result)) {
		header('location:index.php');
	}
}
$pdo_statement = $pdo_conn->prepare("SELECT * FROM tbl_episode where episodeid=" . $_GET["id"]);
$pdo_statement->execute();
$result = $pdo_statement->fetchAll();

$pdoguests = $pdo_conn->prepare("SELECT guestName, guestProfile FROM tbl_guests");
$pdoguests->execute();
$names = $pdoguests->fetchAll();

?>
<div class="container">
<div class="demo-form-row text-center">
  <a href="index.php" class="button_link">Back to List</a>
  <a onclick="confirmationDelete(this);return false;" id="ajax-action-links" class="button_delete" href='/project1/delete.php?id=<?php echo $_GET["id"]; ?>'>Delete Record</a></div>
<div class="row">
<h1 class="demo-form-heading">Edit Record</h1>
<form name="frmAdd" action="" method="POST" class="form-group">
<div class="col-xs-12 col-sm-12 col-md-12 borderBottom">
  <div class="col-xs-12 col-sm-6 col-md-6">
    <div class="demo-form-row">
  	  <label>Title: </label><br>
  	  <input type="text" name="post_title" class="demo-form-field form-control" value="<?php echo $result[0]['episodetitle']; ?>" required />
    </div>
    <div class="demo-form-row">
  	  <label>Episode Intro: </label><br>
  	  <textarea name="description" class="demo-form-field form-control" rows="5"><?php echo $result[0]['episodeintro']; ?></textarea>
    </div>
    <div class="demo-form-row">
      <label>Date: </label><br>
      <input type="date" name="post_at" class="demo-form-field form-control" value="<?php echo $result[0]['episodepublishdate']; ?>"/>
    </div>
  </div>
  <div class="col-xs-12 col-sm-6 col-md-6">
  	<div class="demo-form-row">
  		<?php
      function status($var){
  			   if($var == 1 ){
  			      echo "Idea";
  			   }elseif($var== 2){
  			     echo "Research";
  			   }elseif($var== 3){
  				 echo "Guest Confirmed";
  			   }elseif($var== 4){
  			      echo "Interview Done";
  			   }elseif($var== 5){
  			      echo "Edited";
            }elseif($var== 6){
   			      echo "Ready for Publication";
            }elseif($var== 7){
               echo "Published";
            }elseif($var== 8){
               echo "Abandoned";
            }else{
  				   //Do nothing
  			     }
           }

  		?>
  		<h4><span class="thestatuspan">Status:</span> <span style="color:#87CEFA"><?php status($result[0]['epstid']);?></span></h4>
  			<h4>Change Status</h4><select name="statusupdate">
  				<option value="1">Idea</option>
  				<option value="2">Research</option>
  				<option value="3">Guest Confirmed</option>
  				<option value="4">Interview Done</option>
          <option value="5">Edited</option>
          <option value="6">Ready for Publication</option>
          <option value="7">Published</option>
          <option value="8">Abandoned</option>
  			</select>
  		</div>

  	<!-- The Guest List elements -->
  	<div class="demo-form-row">
  		<h4>Existing Guest</h4>
      <?php if(!empty($names)){?>
        <ul class="list-group">
          <?php foreach($names as $name) { ?>
            <li class="list-group-item"><input id="chk"type="checkbox" value="<?php echo $name['guestName'];?>" name="guestlist[]"> <?php echo $name["guestName"];?> | <a href="<?php echo $name['guestProfile']; ?>"><?php echo $name["guestName"];?> 's Profile</a></li>
          <?php } ?>
        </ul>
       <?php } ?>
  	</div>
  </div>
</div><!-- End both containers field with borders -->
	<!-- End of the Guest List -->
  <div class="col-xs-12 col-sm-12 col-md-12 text-center demo-form-row">
	  <input id="srecord" name="save_record" type="submit" value="Save" class="demo-form-submit">
  </div>
  </form>
</div><!-- End FrmAdd div -->

<?php
	 if(!empty($_POST["add_new_guest"])) {
	$query = "INSERT INTO tbl_guests (guestName, guestEmail) VALUES( :guestN, :guestE)";
	$pdo_statement = $pdo_conn->prepare( $query );
	$res = $pdo_statement->execute( array( ':guestN'=>$_POST['new_guest'],':guestE'=>$_POST['new_guest_email']));
	if (!empty($res) ){
		header('location:add.php');
	}
}
?>
<div class="row borderBottom">
		<h4>New Guests</h4>
		<form action="" method="POST" class="form-group">
      <div class="allmarg col-xs-12 col-sm-4 col-md-4">
		 <input type="text" name="new_guest" class="form-control" placeholder="New Guest" required>
   </div>
   <div class="allmarg col-xs-12 col-sm-4 col-md-4">
		 <input type="text" name="new_guest_email" class="form-control" placeholder="Guest Email" required>
   </div>
   <div class="col-xs-12 col-sm-4 col-md-3">
		 <input name="add_new_guest" type="submit" value="Submit" class="marg10 demo-form-newuser">
   </div>
		</form>
	</div><!--end new guest list -->
  </div>
<script type="text/javascript">
function confirmationDelete(anchor)
{
   var conf = confirm('Are you sure want to delete this record?');
   if(conf)
      window.location=anchor.attr("href");
}

</script>
<?php include "footer.php"; ?>
