<?php
require_once("db.php");
include "header.php";
?>
<div class="container">
  <div style="margin:10px 10px 20px 10px;"><a href="index.php" class="button_link">Back to List</a></div>
<?php
echo "Tasks for id: ". $_GET['id']."!";
$taskquery = "SELECT `taskDescription`, `taskDate` FROM tblTasks WHERE taskEpisodeID = '".$_GET['id']."' ";
$pdo_statement = $pdo_conn->prepare($taskquery);
$pdo_statement->execute();
?>
<!-- Section of the task list -->
<div class="demo-form-row">
  <table class="tbl-qa table-bordered">
    <thead>
  	<tr>
  	  <th class="table-header">Task Description</th>
      <th class="table-header">Task Date</th>
  	</tr>
    </thead>
  <tbody id="table-body">
	<?php
            while($res = $pdo_statement->fetch(PDO::FETCH_ASSOC)):
	?>
  <tr class="table-row">
  <td><?php echo $res["taskDescription"]; ?></td>
  <td><?php echo $res["taskDate"]; ?></td>
  <?php endwhile; ?>
</tbody>
</table>
</div><!-- End div for demo form -->

<!-- Displaying episode data -->
<?php
// $episodedataquery = "SELECT `episodeid`,`episodetitle`,`episodeGuests`,`episodeintro`,`episodepublishdate`, `episodenotes` FROM `tbl_episode` WHERE episodeid = '". $_GET['id']."' ";
// $statement = $pdo_conn->prepare($episodedataquery);
// $statement->execute();
 ?>
<!-- <ul>
  <?php //while($data = $statement->fetch(PDO::FETCH_ASSOC));?>
  <li><b>Episode Title: </b><?php //echo $data["episodetitle"]; ?></li>
  <li><b>Code Episode: </b><?php //echo $data["episodecode"]; ?></li>
  <li><b>Episode Guests: </b><?php //echo $data["episodeGuests"]; ?></li>
  <li><b>Episode Intro: </b><?php //echo $data["episodeintro"]; ?></li>
  <li><b>Episode Date: </b><?php //echo $data["episodepublishdate"]; ?></li>
  <li><b>Episode Notes: </b><?php //echo $data["episodenotes"]; ?></li>
<?php //endwhile;?>
</ul> -->
<!-- End episode view -->

<!-- Section when we add the new tasks-->
<div class="row frm-add">
  <?php
  if(!empty($_POST["addTask"])) {
  	$sql = "INSERT INTO tblTasks ( taskDescription, taskDate, taskEpisodeID) VALUES ( :task_decription, :task_date, :taskoutId)";
  	$pdo_statement = $pdo_conn->prepare( $sql );
  	$result = $pdo_statement->execute( array( ':task_decription'=>$_POST['taskdescriptioname'],':task_date'=>$_POST['taskdateadd'], ':taskoutId'=>$_GET['id'] ) );
  	if (!empty($result) ){
  	  header('location:index.php');
  	}
  }

  ?>
<!-- Add a new task to this specific id -->
<form name="frmAdd" action="" method="POST" class="form-group">
  <h3>Add New Task to this episode</h3>
  <div class="col-xs-12 col-sm-4 col-md-4">
  <label>Task Description</label>
  <input type="text" name="taskdescriptioname" class="demo-form-field form-control"/>
  </div>
  <div class="col-xs-12 col-sm-4 col-md-4">
  <label>New Task </label>
  <input type="date" name="taskdateadd" class="demo-form-field form-control"/>
  </div>
  <div class="marg20 col-xs-12 col-sm-4 col-md-4">
  <input type="submit" name="addTask" value="Add Task" class="demo-form-submit" >
  </div>
</form>
<!-- End of added form -->
</div>
</div><!-- End wrapper -->
<?php include "footer.php"; ?>
