-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 198.71.225.63:3306
-- Generation Time: Sep 28, 2018 at 09:15 AM
-- Server version: 5.5.51-38.1-log
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kblanqua_flowtn`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblTasks`
--

CREATE TABLE `tblTasks` (
  `taskID` bigint(20) NOT NULL,
  `taskEpisodeID` bigint(20) NOT NULL,
  `taskDescription` text NOT NULL,
  `taskDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblTasks`
--

INSERT INTO `tblTasks` (`taskID`, `taskEpisodeID`, `taskDescription`, `taskDate`) VALUES
(1, 14, 'Older Task', '0000-00-00'),
(2, 16, 'New Tasks', '0000-00-00'),
(3, 14, 'Older Older Task', '0000-00-00'),
(4, 15, 'Newer Date', '0000-00-00'),
(5, 14, 'Tester', '2018-09-25'),
(6, 31, 'Confirm The Guest', '2018-09-20');

-- --------------------------------------------------------

--
-- Table structure for table `tblTaskTemplates`
--

CREATE TABLE `tblTaskTemplates` (
  `templateTaskID` bigint(20) NOT NULL,
  `templateTaskDescription` text NOT NULL,
  `templateTaskDaysRelative` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_episode`
--

CREATE TABLE `tbl_episode` (
  `episodeid` bigint(20) NOT NULL,
  `episodetitle` longtext NOT NULL,
  `episodecode` text NOT NULL,
  `episodeGuests` varchar(80) DEFAULT NULL,
  `epstid` int(40) NOT NULL DEFAULT '1',
  `episodenotesURL` text NOT NULL,
  `episodeintro` longtext NOT NULL,
  `episodepublishdate` date NOT NULL,
  `episodenotes` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_episode`
--

INSERT INTO `tbl_episode` (`episodeid`, `episodetitle`, `episodecode`, `episodeGuests`, `epstid`, `episodenotesURL`, `episodeintro`, `episodepublishdate`, `episodenotes`) VALUES
(14, 'Great Thing', 'code1', 'Slim Shady', 1, '', 'lklijokjhoiuj', '0000-00-00', ''),
(16, 'Episode 2', 'code2', 'Slim Shady', 8, '', '', '0000-00-00', ''),
(31, 'Episode 3', 'code3', '', 1, '', 'The 3-d episode of the podcast - testing if this gets truncated or not? tadaa', '2018-09-20', ''),
(33, 'epsiode 4', 'cd445', '', 1, '', '', '2018-09-22', ''),
(34, 'Expats for L', 'XY', '', 1, '', 'ghjgjjhg', '0000-00-00', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_episodestatus`
--

CREATE TABLE `tbl_episodestatus` (
  `episodestatusid` bigint(20) NOT NULL,
  `episodestatus` tinytext,
  `episodestatusrequiresaction` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_episodestatus`
--

INSERT INTO `tbl_episodestatus` (`episodestatusid`, `episodestatus`, `episodestatusrequiresaction`) VALUES
(1, 'Idea', -1),
(2, 'Research', -1),
(3, 'Guests Confirmed', -1),
(4, 'Interview Done', -1),
(5, 'Edited', -1),
(6, 'Ready for Publication', -1),
(7, 'Published', 0),
(8, 'Abandoned', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guestEpisode`
--

CREATE TABLE `tbl_guestEpisode` (
  `guestepisodeid` bigint(20) NOT NULL,
  `guestepisodeGuestID` bigint(20) DEFAULT NULL,
  `guestepisodeEpisodeIDID` bigint(20) DEFAULT NULL,
  `guestepisodeguestconfirmed` tinyint(1) DEFAULT NULL,
  `guestportraitdone` tinyint(1) DEFAULT NULL,
  `guestporttraiturl` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guests`
--

CREATE TABLE `tbl_guests` (
  `guestID` int(11) NOT NULL,
  `guestName` varchar(40) NOT NULL,
  `guestEmail` varchar(40) NOT NULL,
  `guestProfile` varchar(40) NOT NULL DEFAULT '#'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_guests`
--

INSERT INTO `tbl_guests` (`guestID`, `guestName`, `guestEmail`, `guestProfile`) VALUES
(1, 'Krenar Lipo', 'vampiri43@yahoo.com', '#'),
(2, 'Slim Shady', 'eminem@yahoo.com', '#'),
(3, 'Tester Poop', 'tester@hotmail.com', '#'),
(5, 'Agim Cani', 'agim@gmail.com', '#'),
(6, 'Besnik Djali', 'niku@hotmail.com', '#'),
(7, 'Artan Nikolla', 'palidhje@yahoo.com', '#');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblTasks`
--
ALTER TABLE `tblTasks`
  ADD PRIMARY KEY (`taskID`);

--
-- Indexes for table `tblTaskTemplates`
--
ALTER TABLE `tblTaskTemplates`
  ADD PRIMARY KEY (`templateTaskID`);

--
-- Indexes for table `tbl_episode`
--
ALTER TABLE `tbl_episode`
  ADD PRIMARY KEY (`episodeid`);

--
-- Indexes for table `tbl_episodestatus`
--
ALTER TABLE `tbl_episodestatus`
  ADD PRIMARY KEY (`episodestatusid`);

--
-- Indexes for table `tbl_guestEpisode`
--
ALTER TABLE `tbl_guestEpisode`
  ADD PRIMARY KEY (`guestepisodeid`);

--
-- Indexes for table `tbl_guests`
--
ALTER TABLE `tbl_guests`
  ADD PRIMARY KEY (`guestID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblTasks`
--
ALTER TABLE `tblTasks`
  MODIFY `taskID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tblTaskTemplates`
--
ALTER TABLE `tblTaskTemplates`
  MODIFY `templateTaskID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_episode`
--
ALTER TABLE `tbl_episode`
  MODIFY `episodeid` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `tbl_episodestatus`
--
ALTER TABLE `tbl_episodestatus`
  MODIFY `episodestatusid` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_guestEpisode`
--
ALTER TABLE `tbl_guestEpisode`
  MODIFY `guestepisodeid` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_guests`
--
ALTER TABLE `tbl_guests`
  MODIFY `guestID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
