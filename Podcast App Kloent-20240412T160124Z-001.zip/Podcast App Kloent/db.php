<?php
	$database_username = 'kblanqua_flowtn';
	$database_password = 'UUJGgK~pW[14';
	$pdo_conn = new PDO( 'mysql:host=198.71.225.63:3306;dbname=kblanqua_flowtn', $database_username, $database_password );
?>