<?php
require_once("db.php");
$pdo_statement=$pdo_conn->prepare("delete from tbl_episode where episodeid=" . $_GET['id']);
$pdo_statement->execute();
header('location:index.php');
?>