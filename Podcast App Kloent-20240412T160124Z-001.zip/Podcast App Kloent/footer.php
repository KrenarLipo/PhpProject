<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
  $(document).on('click', '#srecord', function() {
      if ($("#chk").is(":checked")) {
      var chk = $('#chk').val();
      }else{
       chk = 0;
      }
    })
});
</script>
</body>
</html>
