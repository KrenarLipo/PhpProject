
<h2>Jemi tek footeri</h2>
</body>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.print.min.js"></script>
<script type="text/javascript" language="javascript">
    $(document).ready(function(){

       $('#container').DataTable( {
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ],
            "ajax": {
            "url": "indexx.php",
            "type": "GET"
            }
        });

    });
    

         
         //Hapja e javascriptit per insert
        //  $(document).on('submit', '#user_form', function(event){
        //      event.preventDefault();
        //      var firstname = $('#username').val();
        //      var surname = $('#surname').val();
        //      var email = $('#email').val();
        //      var password = $('#upassword').val();
             
        //      if(firstname!=''&&email!=''&&password!=''&&phone!=''){
        //          $.ajax({
        //              url: "add_User.php",
        //              method :"POST",
        //              data : new FormData(this),
        //              contentType: false,
        //              processData: false,
        //              success:function(data){
        //                 alert(data);
        //                 $('#user_form')[0].reset();
        //                 $('#userModal').modal('hide');
        //                 dataTable.ajax.reload();
        //              }
        //          });
        //      }else{
        //          alert("All the fields with star are Required");
        //      }
        //  });

        //  //Delete section
         $(document).on('click', '.print', function(){
          var user_id = $this.attr("id_customer");
        if(confirm("Are you sure, you want to print this?")){
        $.ajax({
         url: "indexx.php",
                    method:"POST",
                    data:{user_id:user_id},
                     success:function(data){
                     alert(data);
                        dataTable.ajax.reload();
                  }
                });
          }else{
                 return false;
             }   
         });
         
         


</script>

</html>
