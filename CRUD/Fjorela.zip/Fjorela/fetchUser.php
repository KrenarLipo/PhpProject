<?php
session_start();
include "header.php";


$database = new Connection();
$db = $database->open();

$query = '';
$output = array();

$query .= "SELECT id,username,surname,email,password FROM user";

/* ==== Searchi i Datatables ==== */
// if(isset($_POST["search"]["value"])){
//     $query .= 'WHERE username LIKE "%'.$_POST["search"]["value"].'%"';
//     $query .= 'OR surname LIKE "%'.$_POST["search"]["value"].'%"';
//     $query .= 'OR phone LIKE "%'.$_POST["search"]["value"].'%"';
// }
// /* ==== Aktivizimi i shigjetave per fitrim ==== */ 
// if(isset($_POST["order"])){
//     $query .= 'ORDER BY'.$_POST['order']['0']['column'].' '.$_POST['order']['0']['dir'].'';
// }else{
 $query .= 'ORDER BY id_customer ';
// }
// /* ==== Afishimi nepermjet numrit te elementeve per faqe (Pagination) ==== */
if($_POST["length"]!= -1) {
 $query .= 'LIMIT ('.$_POST['start'] . ', ' .$_POST['length'].')'; // LIMIT(1,5)
// }

$stmt = $db->prepare($query);
$stmt->execute();

$result = $stmt->fetchAll(); //Marre gjithe te dhenat nga databasa
var_dump($result);
echo"<br>";
$data = array();

$filtered_rows = $stmt->rowCount(); //Gjen gjithe rreshtat qe kemi, totalin

/* ==== Mbushja e array-t data ==== */
foreach($result as $row) {
    $sub_array = array();

    /* ==== mbushja e sub-arrayt per secilin element nga databasa ==== */
    $sub_array[] = $row["id"];
    $sub_array[] = $row["username"];
    $sub_array[] = $row["surname"];
    $sub_array[] = $row["email"];
    $sub_array[] = $row["password"];
   

    /* ==== kalimi ite dhenave nga sub_array tek data ==== */
    $data[] = $sub_array;
}

$db = $database->close();

function get_total_all_records(){
    
    $username = 'root';
    $password = '';
    $dbc = new PDO('mysql:host=localhost; dbname = fjorela', $username, $password);

    $statement = $dbc->prepare("SELECT id,username,surname,email,password FROM user");
    $statement->execute();
    
    return $statement->rowCount();
}

/* ==== Mbushja e outputit ==== */
$output = array (
    "draw" => intval($_POST["draw"]),
    "recordsTotal" => $filtered_rows,
    "recordsFiltered" => 23,
    "data" => $data
);

echo json_encode($output);

include "footer.php";
?>