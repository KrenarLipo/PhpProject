<?php
session_start();
include "header.php";
 
    if(isset($_POST["add-user"])){
        $database = new Connection();
		$db = $database->open();
        try {

            $stmt = $db->prepare("INSERT INTO user (name, surname, email, passwordi, phone) VALUES(:user_name,:user_surname,:user_email,:user_password,:user_phone)");
             if($_POST['user-name'] == "" || $_POST['user-email'] == "" || $_POST['user-password'] == ""){
                $_SESSION['message'] = "Plotesoni fielded qe mungojne";
             }else{
                $_SESSION['message'] = ($stmt->execute(array(':user_name'=>$_POST['user-name'], ':user_surname'=>$_POST['user-surname'], ':user_email'=>$_POST['user-email'],
                ':user_password'=>password_hash($_POST['user-password'], PASSWORD_DEFAULT), ':user_phone'=>$_POST['user-phone'])))?'Fatura u shtua me sukses':'Fatura nuk mundi te shtohej';
             }
        }catch(PDOException $e) {
            $_SESSION['message'] = $e->getMessage();
        }
     
		$database->close();
    }else{
		$_SESSION['message'] = 'Fill up add form first';
	}
    
    header('location: index.php');
?>