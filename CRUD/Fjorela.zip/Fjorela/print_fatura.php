<?php
    session_start();
    include_once('header.php');

    if(isset($_POST['print'])){
        $database = new Connection();
        $updatedb = $database->open();


        $username = 'root';
        $password =  ' ';
        $dbc = new POD('mysql:host=localhost; dbname = fjorela',$username, $password);
        $sql = "SELECT * FROM fatura ORDER BY id_customer DESC";
     
      $(document).ready(function() {
       $('.container').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );

header('location: indexx.php'); 

include "footer.php";

?>