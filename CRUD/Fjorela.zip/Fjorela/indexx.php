<?php 
include "header.php";
  session_start();
  if(isset($_SESSION['message'])){
      ?>
      <div class="alert alert-info text-center" style="margin-top:20px;">
          <?php echo $_SESSION['message']; ?>
      </div>
      <?php

      unset($_SESSION['message']);
  }
 
?>
<style>
.text-left {
  float:left;
  margin-bottom:20px;
}
</style>container

<?php
  $database = new Connection();
  $db = $database->open();
?>
<div class="">
  <div style ="text-align:right; margin:20px 0px;">
    <!-- Button trigger indert modal -->
    <button type="button" class="btn btn-primary text-left" data-bs-toggle="modal" data-bs-target="#exampleModal">
    <span class="glyphicon glyphicon-plus"></span> Shto fature
    </button>
    <table class="table table-responsive">
      <thead>
        <tr>
          <th class="table-header">ID</th>
          <th class="table-header">Name</th>
          <th class="table-header">Surname</th>
          <th class="table-header">Amount</th>
          <th class="table-header">Period</th>
          <th class="table-header">Status</th>
         
        </tr>
      </thead>
      <tbody id="table-body">
      <?php 
          try {
             $sql = "SELECT * FROM fatura ORDER BY id_customer DESC";
             foreach($db->query($sql) as $row) {      
      ?>
        <tr class="table-row">
        <td><?php echo $row['id_customer'];?></td>
          <td><?php echo $row['Name'];?></td>
          <td><?php echo $row['Surname'];?></td>
          <td><?php echo $row['AMOUNT'];?></td>
          <td><?php echo $row['Period'];?></td>
          <td><?php echo $row['Status'];?></td>
          
          <td>
            <a href="#edit_<?php echo $row['id_customer']; ?>" class="btn btn-success btn-sm" data-toggle="modal"><span class="glyphicon glyphicon-edit"></span> Ndrysho</a>
					  <a href="#delete_<?php echo $row['id_customer']; ?>" class="btn btn-danger btn-sm" data-toggle="modal"><span class="glyphicon glyphicon-trash"></span> Fshi</a>
          </td>
          <?php //include('edit_delete_modal.php'); ?>
        </tr>
        <?php
              }
            }catch(PDOException $e){
              echo "Ka nje problem me lidhjen: " . $e->getMessage();
            }
            //close connection
            $database->close();
          ?>
      </tbody>
    </table>
  </div>
   <?php 
     $pasword_uncripted = "1234";
     echo $pasword_uncripted.'<br/>';
     echo password_hash($pasword_uncripted, PASSWORD_DEFAULT);          
?>

</div>

<div class="container">

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <form method="POST" action="insert.php">
            ID: <input class="form-control" type = "number" name="id_customer" />
            Name: <input class="form-control" type = "text" name="Name" />
            Surname: <input class="form-control" type = "text" name="Surname" />
            Amount: <input class="form-control" type = "number" name="AMOUNT" />
            Period: <input class="form-control" type="text" name="Period" />
            Status: <input class="form-control" type="text" name="Status" />       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" name="add_record" class="btn btn-primary">Shto Fature</button>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- End insert modal -->
    
</div>

<?php
  include "footer.php";
?>