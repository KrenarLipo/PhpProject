-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2021 at 12:02 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fjorela`
--

-- --------------------------------------------------------

--
-- Table structure for table `fatura`
--

CREATE TABLE `fatura` (
  `id_customer` int(50) NOT NULL,
  `Name` varchar(50) CHARACTER SET utf8mb4 NOT NULL,
  `Surname` varchar(50) CHARACTER SET utf8mb4 NOT NULL,
  `AMOUNT` int(50) NOT NULL,
  `Period` varchar(50) NOT NULL,
  `Status` varchar(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fatura`
--

INSERT INTO `fatura` (`id_customer`, `Name`, `Surname`, `AMOUNT`, `Period`, `Status`) VALUES
(1, 'klienti 1', 'numer 1', 50000, 'muaji prill', '0'),
(2, 'klienti 2', 'numer 2', 75000, 'muaji prill', '0'),
(3, 'klienti 3', 'numer 3', 15000, 'muaji prill', '0'),
(4, 'klienti 4', 'numer 4', 35000, 'muaji prill', '0'),
(5, 'klienti 5', 'numer 5', 72000, 'muaji prill', '0'),
(6, 'klienti 6', 'numer 6', 25000, 'muaji prill', '0'),
(7, 'klienti 7', 'numer 7', 45000, 'muaji prill', '0'),
(8, 'klienti 8', 'numer 8', 55000, 'muaji prill', '0'),
(9, 'klienti 9', 'numer 9', 85000, 'muaji prill', '0'),
(10, 'klienti 10', 'numer 10', 34000, 'muaji prill', '0'),
(11, 'klienti 11', 'numer 11', 51000, 'muaji prill', '0'),
(12, 'klienti 12', 'numer 12', 46000, 'muaji prill', '0'),
(13, 'klienti 13', 'numer 13', 29000, 'muaji prill', '0'),
(14, 'klienti 14', 'numer 14', 59000, 'muaji prill', '0'),
(15, 'klienti 15', 'numer 15', 76000, 'muaji prill', '0'),
(16, 'klienti 16', 'numer 16', 77000, 'muaji prill', '0'),
(17, 'klienti 17', 'numer 17', 64000, 'muaji prill', '0'),
(18, 'klienti 18', 'numer 18', 48000, 'muaji prill', '0'),
(19, 'klienti 19', 'numer 19', 54000, 'muaji prill', '0'),
(20, 'klienti 20', 'numer 20', 38000, 'muaji prill', '0'),
(21, 'klienti 21', 'numer 21', 46000, 'muaji prill', '0'),
(22, 'klienti 22', 'numer 22', 47000, 'muaji prill', '0'),
(23, 'klienti 23', 'numer 23', 53000, 'muaji prill', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fatura`
--
ALTER TABLE `fatura`
  ADD PRIMARY KEY (`id_customer`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fatura`
--
ALTER TABLE `fatura`
  MODIFY `id_customer` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
