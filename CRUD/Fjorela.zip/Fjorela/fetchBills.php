<?php
session_start();
include "header.php";


$database = new Connection();
$db = $database->open();

$query = "";
$output = array();

$query .= "SELECT id_customer,Name,Surname,AMOUNT,Period, Status FROM fatura";

 

if(isset($_POST["search"]["value"])){
     $query .= 'WHERE Name LIKE "%'.$_GET["search"]["value"].'%"';
        $query .= 'OR Surname LIKE "%'.$_GET["search"]["value"].'%"';
         $query .= 'OR phone LIKE "%'.$_GET["search"]["value"].'%"';
   }
     /* ==== Aktivizimi i shigjetave per fitrim ==== */ 
     if(isset($_GET["order"])){
       $query .= 'ORDER BY'.$_GET['order']['0']['column'].' '.$_GET['order']['0']['dir'].'';
     }else{
       $query .= 'ORDER BY id ';
    }
    /* ==== Afishimi nepermjet numrit te elementeve per faqe (Pagination) ==== */
     if($_GET["length"]!= 23) {
        $query .= 'LIMIT ('.$_GET['start'] . ', ' .$_GET['length'].')'; // LIMIT(1,5)
     }
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    
    $result = $stmt->fetchAll(); //Marre gjithe te dhenat nga databasa
    var_dump($result);
    echo"<br>";
    $data = array();
    
    $filtered_rows = $stmt->rowCount(); //Gjen gjithe rreshtat qe kemi, totalin
    
    /* ==== Mbushja e array-t data ==== */
    foreach($result as $row) {
        $sub_array = array();
    
        /* ==== mbushja e sub-arrayt per secilin element nga databasa ==== */
        $sub_array[] = $row["id_customer"];
        $sub_array[] = $row["Name"];
        $sub_array[] = $row["Surname"];
        $sub_array[] = $row["AMOUNT"];
        $sub_array[] = $row["Period"];
        $sub_array[] = $row["Status"];
       
    
        /* ==== kalimi ite dhenave nga sub_array tek data ==== */
        $data[] = $sub_array;
    }
    
    $db = $database->close();
    
    function get_total_all_records(){
        
        $username = 'root';
        $password = '';
        $dbc = new PDO('mysql:host=localhost; dbname = fjorela', $username, $password);
    
        $statement = $dbc->prepare("SELECT id_customer,Name,Surname,AMOUNT,Period, Status FROM fatura");
        $statement->execute();
        
        return $statement->rowCount();
    }
    
    /* ==== Mbushja e outputit ==== */
   // $output = array (
    //    "draw" => intval($_GET["draw"]),
     //   "recordsTotal" => $filtered_rows,
     //   "recordsFiltered" => 23,
    //    "data" => $data
   // );
    
   // echo json_encode($output);
    
    
    include "footer.php";
    ?>