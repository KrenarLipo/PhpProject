<?php

//fetch.php

session_start();
include "header.php";


$database = new Connection();
$db = $database->open();

$query = "";
$output = array();

$query .= "SELECT id_customer,Name,Surname,AMOUNT,Period, Status FROM fatura";

if(isset($_POST["search"]["value"]))
{
	$query .= '
	WHERE id_customer LIKE "%'.$_POST["search"]["value"].'%" 
	OR Name LIKE "%'.$_POST["search"]["value"].'%" 
	OR Surname LIKE "%'.$_POST["search"]["value"].'%" 
	OR AMOUNT LIKE "%'.$_POST["search"]["value"].'%" 
	OR Period LIKE "%'.$_POST["search"]["value"].'%" 
    OR Status LIKE "%'.$_POST["search"]["value"].'%" 
	';
}

if(isset($_POST['order']))
{
	$query .= 'ORDER BY '.$column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
}
else
{
	$query .= 'ORDER BY customer_id DESC ';
}

$query1 = '';

if($_POST['length'] != -1)
{
	$query1 = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

$statement = $connect->prepare($query);

$statement->execute();

$number_filter_row = $statement->rowCount();

$result = $connect->query($query . $query1);

$data = array();

foreach($result as $row)
{
	$sub_array = array();

	$sub_array[] = $row['id_customer'];

	$sub_array[] = $row['Name'];

	$sub_array[] = $row['Surname'];

	$sub_array[] = $row['AMOUNT'];

	$sub_array[] = $row['Period'];

    $sub_array[] = $row['Status'];

	$data[] = $sub_array;
}

function count_all_data($connect)
{
	$query = "SELECT * FROM fatura";

	$statement = $connect->prepare($query);

	$statement->execute();

	return $statement->rowCount();
}

$output = array(
	"draw"		=>	intval($_POST["draw"]),
	"recordsTotal"	=>	count_all_data($connect),
	"recordsFiltered"	=>	$number_filter_row,
	"data"		=>	$data
);



?>