<?php
session_start();
include "header.php";
 
    if(isset($_POST["add_record"])){
        $database = new Connection();
		$db = $database->open();
        try {

            $stmt = $db->prepare("INSERT INTO cars (id_customer, Name, Surname, AMOUNT, Period, Status) VALUES(:id_customer:Name,:Surname,:AMOUNT,:Period,:Status)");
    
            $_SESSION['message'] = ($stmt->execute(array(':id_customer'=>$_POST['id_customer'],':Name'=>$_POST['Name'], ':Surname'=>$_POST['Surname'], ':AMOUNT'=>$_POST['AMOUNT'],
                                                    ':Period'=>$_POST['Period'], ':Status'=>$_POST['Status'])))?'Fatura u shtua me sukses':'Pati nje problem ne shtim';
        }catch(PDOException $e) {
            $_SESSION['message'] = $e->getMessage();
        }
       //close connection
		$database->close();
    }else{
		$_SESSION['message'] = 'Fill up add form first';
	}
    
    header('location: index.php');
?>

