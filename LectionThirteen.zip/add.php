<?php

include 'db.php';

if(isset($_POST['send'])){

    $brend = $_POST['brand'];
    $model = $_POST['model'];
    $type = $_POST['carType'];
    $price = $_POST['price'];

    $sql = "INSERT INTO makinat (Brand, Model, Type, Price) 
            VALUES ('$brend', '$model', '$type', '$price')";
    
    $res = $db->query($sql);

    $Message = urlencode("Car Added Succesfully");

    if($res){
        header('location: index.php?Message='.$Message);
        die;
    }
}

?>