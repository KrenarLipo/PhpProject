<script
  src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
 <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" ></script>

<script>
	function del_Users(id){
		if(confirm("Are you sure do you want to delete this car?")){
			document.location.href = 'delete.php?id='+id;
		}
	}
</script>

</body>

</html>
