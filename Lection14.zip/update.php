<?php

include "header.php";

$id = (int) $_GET['id'];

$Message = urlencode("Car updated Succesfully!");

$sql = "SELECT * FROM makinat WHERE id ='$id' ";

$rows = $db->query($sql);

$myrow = $rows->fetch_assoc();

if(isset($_POST['send'])){
  $brand = htmlspecialchars($_POST['brand']);
  $model = htmlspecialchars($_POST['model']);
  $type = $_POST['carType'];
  $price = $_POST['price'];

   $updateQuery = "UPDATE makinat
                   SET Brand = '$brand', Model = '$model', Type = '$type', Price = '$price'
                   WHERE id = '$id'
                  ";
 $db->query($updateQuery);
 header('location: index.php?UpdateMessage='.$Message);
}
?>

<div class="container">
  <div class="row">
      <center><h2>Update car</h2></center>
      <div class="col-md-10 col-md-offset-1">
          <form method="post">
             <div class="form-group">
                 <label>Brand*</label>
                 <input type="text" value="<?php echo $myrow['Brand'];?>" name="brand" class="form-control" required>
                 <label>Model*</label>
                 <input type="text" value="<?php echo $myrow['Model'];?>" name="model" class="form-control" required>
                 <label>Type</label>
                 <input type="text" value="<?php echo $myrow['Type'];?>" name="carType" class="form-control">
                 <label>Price*(EUR)</label>
                 <input type="text" value="<?php echo $myrow['Price'];?>" name="price" class="form-control" required>
             </div>
             <input type="submit" name="send" value="Update Car" class="btn btn-info">
          </form>
          <br>
          <a href="index.php" class="btn btn-success">Return Back</a>
      </div>
  </div>
</div>

<?php include 'footer.php';?>
