-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 16, 2019 at 01:28 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `menaxhimmakinash`
--

-- --------------------------------------------------------

--
-- Table structure for table `makinat`
--

CREATE TABLE `makinat` (
  `id` int(11) NOT NULL,
  `Brand` varchar(50) DEFAULT NULL,
  `Model` varchar(50) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `Price` mediumint(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `makinat`
--

INSERT INTO `makinat` (`id`, `Brand`, `Model`, `Type`, `Price`) VALUES
(1, 'Mercedez', 'Avangarda', 'Electric car', 150000),
(2, 'BMW', 'X6', 'Oil cars', 200000),
(4, 'Toyota', 'Yaris', 'Electric', 30000),
(5, 'AlfaRomeo', 'A300', 'Diesel', 35000),
(6, 'Mitsubishis', 'Pagero Pini', 'Oil', 40000),
(7, 'Fiat', 'Panda', 'Diesel', 15000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `makinat`
--
ALTER TABLE `makinat`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `makinat`
--
ALTER TABLE `makinat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
