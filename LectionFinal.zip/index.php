
  <?php

  include "header.php";
  include "db.php";

  $page = (isset($_GET['page']) ? (int) $_GET['page']: 1);
  $perPage = (isset($_GET['per-page']) && (int) ($_GET['per-page']) <=50 ? (int) $_GET['per-page'] : 5);

  $start = ($page > 1) ? ($page*$perPage) - $perPage : 0;

  $sql = "SELECT * FROM makinat LIMIT ".$start.",".$perPage."";
  $total = $db->query("SELECT * FROM makinat")->num_rows;
  $pages = ceil($total/$perPage);
  $rows = $db->query($sql);

  //$sql = "SELECT * FROM makinat" ;
  //$rows = $db->query($sql);

  ?>

<div class="container">
    <div class="row">
    <span class="success">
    <?php if(isset($_GET['Message']))
          {
            echo $_GET['Message'];
          }else{
            echo "";
          }
     ?>
    </span>
    <span class="success">
    <?php if(isset($_GET['UpdateMessage']))
          {
            echo $_GET['UpdateMessage'];
          }else{
            echo "";
          }
     ?>
    </span>

    <h1>Welcome <?php echo $login_session ?></h1>
    <h2><a href="logout.php">Sign Out</a></h2>
        <center>
            <h2>Car management</h2>
        </center>

        <div class="col-md-10 col-md-offset-1">
            <table class="table table-bordered">
            <button type="button" data-toggle = "modal" data-target="#addCar" class="btn btn-success">Add Car</button>
            <button type="button" class="btn btn-default pull-right" onclick="print()">Car Details</button>
            <hr><br>
                <thead>
                    <tr>
                    <th>Code</th>
                    <th>Brand</th>
                    <th>Model</th>
                    <th>Type</th>
                    <th>Price</th>
                    <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                    <?php while($row = $rows->fetch_assoc()): ?>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['Brand']; ?></td>
                    <td><?php echo $row['Model']; ?></td>
                    <td><?php echo $row['Type']; ?></td>
                    <td><?php echo $row['Price']; ?> €</td>
                    <td>
                        <a href="update.php?id=<?php echo $row['id'];?>" class="btn btn-primary">Edit</a>
                        <a href="javascript:del_Users(<?php echo $row['id'];?>)" class="btn btn-danger">Delete</a>
                    </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <center>
                <ul class="pagination">
                    <?php for($i = 1; $i<=$pages; $i++):?>
                        <li><a href="?page=<?php echo $i;?>&per-page=<?php echo $perPage;?>">
                            <?php echo $i;?>
                        </a></li>
                    <?php endfor;?>
                </ul>
            </center>
        </div>
        <!-- Modal -->
        <div id="addCar" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add new Car</h4>
            </div>
            <div class="modal-body">
                <form method="post" action="add.php">
                    <div class="form-group">
                        <label>Brand*</label>
                        <input type="text" name="brand" class="form-control" required>
                        <label>Model*</label>
                        <input type="text" name="model" class="form-control" required>
                        <label>Type</label>
                        <input type="text" name="carType" class="form-control">
                        <label>Price*(EUR)</label>
                        <input type="number" name="price" class="form-control" required>
                    </div>
                    <input type="submit" name="send" value="Register Car" class="btn btn-info">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
            </div>

        </div>
        </div>
    </div>
</div>
<?php include "footer.php"; ?>
