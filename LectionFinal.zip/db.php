<?php

$db = new Mysqli;

$db->connect('localhost', 'root', '','menaxhimmakinash');

if(!$db){
    echo "Error in connection!";
}

$error = "";

?>
