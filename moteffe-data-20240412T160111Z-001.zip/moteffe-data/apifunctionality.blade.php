@extends('admin.layouts.admin')

@section('content')

    <table border="1">
 	<tbody>
 		<tr>
      <th>ID</th>
 			<th>Nome</th>
      <th>Detagli</th>
      <th>Categoria Prodotto</th>
 			<th>Colore</th>
      <th>Categoria</th>
      <th>Dimensioni Stampa D'avanti</th>
      <th>Dimensioni Stampa Indietro</th>
      <th>Prezzo Consigliato</th>
      <th>Taglia</th>
      <th>Mockups</th>
      <th>Prezzo in Euro</th>
 		</tr>
         <?php foreach($characters as $character) : ?>
         <tr>
            <td> <?php echo $character['id']; ?> </td>
            <td> <?php echo $character['name']; ?> </td>
            <td> <?php echo $character['details']; ?> </td>
            <td> <?php echo $character['print_category']; ?> </td>
            <td> <?php echo $character['colors'][0]['name']; ?> </td>
            <td> <?php echo $character['category'][0]; ?> </td>
            <td> Larghezza: <?php echo $character['print_size']['front']['w']; ?>  Lungezza: <?php echo $character['print_size']['front']['h'];?></td>
            <td> Larghezza: <?php echo $character['print_size']['back']['w']; ?>  Lungezza: <?php echo $character['print_size']['back']['h'];?></td>
            <td><?php echo $character['recommended_price']['EUR']; ?> </td></td>
            <td><?php
            $letaglie = $character['sizes'];
            foreach ($letaglie as $key) {
            echo $key['name']."<br>";
            }
             ?>
           </td>
            <td> <img width="40" height="auto" src="<?php echo $character['mockups'][0]['image']['b'] ?> "></td>
            <td><?php echo $character['min_price']['EUR'][0]; ?> <b>Euro</b></td>
         </tr>
 		<?php endforeach; ?>
 	</tbody>

@endsection

@section('scripts')

@endsection