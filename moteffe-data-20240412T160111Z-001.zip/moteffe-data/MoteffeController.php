<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Routing\Route;
use Illuminate\Support\Facades\DB;

class MoteffeController extends Controller
{
    public function getMoteffeData() {

        $url = 'https://moteefe.com/api/v1/products.json'; // json url
        //$data = file_get_contents($url);
        $data = file_get_contents($url);
        $characters = json_decode($data, true); // decode json to get datta
        foreach($characters as $char){
            foreach($char as $key => $value){
                //dd($key, $value);
                $insertArr['$key'] = $value;
            }
            DB::table('moteffe_data')->insert($insertArr);
        }
        return view("admin.apifunctionality", compact('characters'));
    }

    // Route::get('/insert-json-file-to-database-table', function(){
    //     $json = file_get_contents(storage_path('demo.json'));
    //     $objs = json_decode($json,true);
    //     foreach ($objs as $obj)  {
    //         foreach ($obj as $key => $value) {
    //             $insertArr[str_slug($key,'_')] = $value;
    //         }
    //         DB::table('examples')->insert($insertArr);
    //     }
    //     dd("Finished adding data in examples table");
    // });



}
